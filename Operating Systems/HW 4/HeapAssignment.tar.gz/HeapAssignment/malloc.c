#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdlib.h>

#define ALIGN4(s)         (((((s) - 1) >> 2) << 2) + 4)
#define BLOCK_DATA(b)      ((b) + 1)
#define BLOCK_HEADER(ptr)   ((struct block *)(ptr) - 1)


static int atexit_registered = 0;
static int num_mallocs       = -1;
static int num_frees         = 0;
static int num_reuses        = 0;
static int num_grows         = -1;
static int num_splits        = 0;
static int num_coalesces     = 0;
static int num_blocks        = 0;
static int num_requested     = 0;
static int max_heap          = 0;


void printer( void )
{
    printf("WE NEED TO SPLIT");
   // printf("\nheap management statistics\n");
}

/*
 *  \brief printStatistics
 *
 *  \param none
 *
 *  Prints the heap statistics upon process exit.  Registered
 *  via atexit()
 *
 *  \return none
 */
void printStatistics( void )
{
  printf("\nheap management statistics\n");
  printf("mallocs:\t%d\n", num_mallocs );
  printf("frees:\t\t%d\n", num_frees );
  printf("reuses:\t\t%d\n", num_reuses );
  printf("grows:\t\t%d\n", num_grows );
  printf("splits:\t\t%d\n", num_splits );
  printf("coalesces:\t%d\n", num_coalesces );
  printf("blocks:\t\t%d\n", num_blocks );
  printf("requested:\t%d\n", num_requested );
  printf("max heap:\t%d\n", max_heap );
}

struct block
{
   size_t      size;  /* Size of the allocated block of memory in bytes */
   struct block *next;  /* Pointer to the next block of allcated memory   */
   bool        free;  /* Is this block free?                     */
};


struct block *FreeList = NULL; /* Free list to track the blocks available */

/*
 * \brief findFreeBlock
 *
 * \param last pointer to the linked list of free blocks
 * \param size size of the block needed in bytes
 *
 * \return a block that fits the request or NULL if no free block matches
 *
 * \TODO Implement Next Fit
 * \TODO Implement Best Fit
 * \TODO Implement Worst Fit
 */
struct block *findFreeBlock(struct block **last, size_t size)
{
    //num_mallocs++;
   struct block *curr = FreeList;
    num_blocks = 0;
#if defined FIT && FIT == 0
   /* First fit */
   while (curr && !(curr->free && curr->size >= size))
   {
      *last = curr;
      curr  = curr->next;
      num_blocks++;
   }
#endif

#if defined BEST && BEST == 0
   //printf("TODO: Implement best fit here\n");
   //GOAL: Find the blocksize closest to our allocation size
   //Method: Loop through all blocks, saving the location of the perfect block
   //struct block *best = FreeList; //We will store the best fit block here
  // int check = curr->size - size; //Check tries to find the tightest fitting block by tracking the space between block size and needed size
   //while ((curr->next->next)!=NULL) //Keeps going through all the blocks
   //{
   /*   if((check > curr->size - size) && (curr->size - size >= 0)) //If the next block has a smaller gap and is not negative, it is our new best block.
      {
      best  = curr;
      check = curr->size - size;  //Our check updates to the next best block we found
      } */
     // *last = curr; //Iterate to the next block
     // curr  = curr->next;
    // num_blocks++;

  // }
   //curr = best;
  // struct block *best = curr;
   //int check = size;
   int check;
   int first = 0;
   int iterations = 0;
   //int best_iterations = 0;
    while (curr != NULL)
    {
      if(curr->free && curr->size >= size) //We found a block that can fit our memory
      {
        if(first == 0)
        {
        first = 1;
        check = (curr->size) - size;
        //best_iterations = iterations;
       // best = curr;
        }
        if(check >= ((curr->size) - size)) //This block fits out memory tighter than any previous, so its our best block
        {
        check = (curr->size) - size;
        //best_iterations = iterations;
       // best = curr
        }
      }
      *last = curr;
      curr  = curr->next;
      iterations++;

    }
    struct block *best = FreeList;
    while(best != NULL)
    {
    num_blocks++;
        if(best->free && best->size >= size)
            if(check == (best->size - size))
                break;
      *last = best;
      best  = best->next;
    } /*
    while(best_iterations > 0)
    {
      *last = best;
      curr  = best->next;
      best_iterations--;
    } */

    return best;
#endif

#if defined WORST && WORST == 0
   //printf("TODO: Implement worst fit here\n");
   int check;
   int first = 0;
   int iterations = 0;
   //int best_iterations = 0;
    while (curr != NULL)
    {
      if(curr->free && curr->size >= size) //We found a block that can fit our memory
      {
        if(first == 0)
        {
        first = 1;
        check = (curr->size) - size;
        //best_iterations = iterations;
       // best = curr;
        }
        if(check <= ((curr->size) - size)) //This block fits our memory looser than any previous, so its our best block
        {
        check = (curr->size) - size;
        //best_iterations = iterations;
       // best = curr
        }
      }
      *last = curr;
      curr  = curr->next;
      iterations++;

    }
    struct block *worst = FreeList;
    while(worst != NULL)
    {
    num_blocks++;
        if(worst->free && worst->size >= size)
            if(check == (worst->size - size))
                break;
      *last = worst;
      worst  = worst->next;
    } /*
    while(best_iterations > 0)
    {
      *last = best;
      curr  = best->next;
      best_iterations--;
    } */

    return worst;

#endif

#if defined NEXT && NEXT == 0
   printf("TODO: Implement next fit here\n");
#endif

   return curr;
}

/*
 * \brief growheap
 *
 * Given a requested size of memory, use sbrk() to dynamically
 * increase the data segment of the calling process.  Updates
 * the free list with the newly allocated memory.
 *
 * \param last tail of the free block list
 * \param size size in bytes to request from the OS
 *
 * \return returns the newly allocated block of NULL if failed
 */
struct block *growHeap(struct block *last, size_t size)
{
   /* Request more space from OS */
   struct block *curr = (struct block *)sbrk(0);
   struct block *prev = (struct block *)sbrk(sizeof(struct block) + size);

   assert(curr == prev);

   /* OS allocation failed */
   if (curr == (struct block *)-1)
   {
      return NULL;
   }

   /* Update FreeList if not set */
   if (FreeList == NULL)
   {
      FreeList = curr;
   }

   /* Attach new block to prev block */
   if (last)
   {
      last->next = curr;
   }
   num_grows++;
   /* Update block metadata */
   curr->size = size;
   curr->next = NULL;
   curr->free = false;
   return curr;
}

/*
 * \brief malloc
 *
 * finds a free block of heap memory for the calling process.
 * if there is no free block that satisfies the request then grows the
 * heap and returns a new block
 *
 * \param size size of the requested memory in bytes
 *
 * \return returns the requested memory allocation to the calling process
 * or NULL if failed
 */
void *malloc(size_t size)
{
   if( atexit_registered == 0 )
   {
      atexit_registered = 1;
      atexit( printStatistics );
   }

   /* Align to multiple of 4 */
   size = ALIGN4(size);
    max_heap = max_heap + size;
    num_requested = max_heap + size;
   /* Handle 0 size */
   if (size == 0)
   {
      return NULL;
   }

   /* Look for free block */
   struct block *last = FreeList;
   num_mallocs++;
   struct block *next = findFreeBlock(&last, size);

   /* TODO: Split free block if possible */
 //  if (size < (next->size))
 //  {

 //  }

   /* Could not find free block, so grow heap */
   if (next == NULL)
   {
      next = growHeap(last, size);
   }

   /* Could not find free block or grow heap, so just return NULL */
   if (next == NULL)
   {
      return NULL;
   }

   /* Mark block as in use */
   next->free = false;
   //num_mallocs++;
   /* Return data address associated with block */
   return BLOCK_DATA(next);
}

/*
 * \brief free
 *
 * frees the memory block pointed to by pointer. if the block is adjacent
 * to another block then coalesces (combines) them
 *
 * \param ptr the heap memory to free
 *
 * \return none
 */
void free(void *ptr)
{
   if (ptr == NULL)
   {
      return;
   }

   /* Make block as free */
   struct block *curr = BLOCK_HEADER(ptr);
   assert(curr->free == 0);
   curr->free = true;
   num_frees++;
   /* TODO: Coalesce free blocks if needed */
}

/* vim: set expandtab sts=3 sw=3 ts=6 ft=cpp: --------------------------------*/

